<?php


$global_vars = [
    'PAY_ID'=>'',
    'SALT'=>'',
    'HOSTED_KEY'=>'',
    'TXNTYPE'=>'SALE',
    'CURRENCY_CODE'=>356,
    'RETURN_URL'=>'http://localhost:8000/response.php',
    'PG_REQUEST_URL' =>'https://secure.pay10.com/pgui/jsp/paymentrequest'
];

 ?>