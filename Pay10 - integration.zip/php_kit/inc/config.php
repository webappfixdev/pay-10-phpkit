<?php

$global_vars = [
'PAY_ID'=>'1003510721230303',
'SALT'=>'65aadf399d904df6',
'TXNTYPE'=>'SALE',
'CURRENCY_CODE'=>356,
'RETURN_URL'=>'https://response.rs.bp.h.teamat.work/',
'PG_REQUEST_URL' =>'https://secure.pay10.com/pgui/jsp/paymentrequest'
];

 ?>